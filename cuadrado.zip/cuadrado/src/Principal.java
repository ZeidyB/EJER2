
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zeidy
 */
public class Principal {
     public static  void main(String[]args){
         cuadrilatero c1;
         float lado1, lado2;
         
         lado1=Float.parseFloat(JOptionPane.showInputDialog("Digute el lado1: "));
         lado2=Float.parseFloat(JOptionPane.showInputDialog("Digute el lado2: "));
         
         
         if(lado1==lado2){//es un cuadrado
             c1=new cuadrilatero(lado1);
         }
         else{
             c1=new cuadrilatero(lado1, lado2);
         }
         System.out.println("El perimetro es: "+ c1.getPerimetro());
         System.out.println("El area es: "+c1.getArea());
     }
}
